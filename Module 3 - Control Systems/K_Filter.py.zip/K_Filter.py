from math import *
import numpy as numpy


def f(mu,sigma2,x):
    coefficient =1.0/ sqrt (2.0 * pi *sigma2)
    exponential= exp(-0.5 * (x - mu) ** 2/sigma2)
    return coefficient * exponential


def update(mean1, var1, mean2,var2):
    new_mean = (var2* mean1 + var1 *mean2)/(var2+var1)
    new_var = 1/(1/var2 + 1/ var1)

    return [new_mean, new_var]


def predict (mean1, var1, mean2,var2):
    new_mean = mean1 + mean2
    new_var = var1 +var2

    return [new_mean,new_var]