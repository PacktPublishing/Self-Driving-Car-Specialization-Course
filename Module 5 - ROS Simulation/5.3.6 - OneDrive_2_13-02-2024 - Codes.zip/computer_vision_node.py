from geometry_msgs.msg import Twist
from rclpy.node import Node 
from .Drive_Bot import Car, Debugging
import rclpy 
import cv_bridge import CvBridge
from sensor_msgs.msg import Image

class Car_driver(Node):
    def __init__(self):

        super().__init__('Driving Node')
        self.subscriber = self.create_subscription (Image,'/camera/image_raw',self.process_data,10)
        self.publisher = self.create_publisher(Twist,'/cmd_vel', 40)
        timer_period = 0.5;self.timer=self.create_timer (timer_period,self.send_cmd_vel)
        self.velocity=Twist()
        self.bridge=CvBridge()
        # self.Debug = Debugging()
        self.Car = Car()


    def send_cmd_vel(self):
        self.publisher.publish(self.velocity)
    
    def process_data(self, data):
        Angle,Speed,img = Car(frame)
        self.velocity.angular.z=Angle
        self.velocity.linear.x=Speed

        cv2.imshow("Frame", img)



def main(args=None):
    rclpy.init(args=args)
    Image_subscriber= Vide0_feed_in()
    rclpy.spin(Image_subscriber)
    rclpy.shutdown()

if __name__ == '__main__':
    main()