import numpy as np

import argparse

import tensorflow as tf

import cv2

from object_detection.utils import ops as utils_ops
from object_detection.utils import label_map_util
from object_detection.utils import visualization_utils as vis_util

utils_ops.tf= tf.compat.v1

tf.gfile = tf.io.gfile

def load_model():
    model=tf.saved_model.load(model_path)
    return model

def run_inference_for_single_image(model, image):
    image = np.asarray(image)
    input_tensor = tf.convert_to_tensor(image)
    input_tensor=input_tensor[tf.newaxis,...]

    output_dict = model (input_tensor)

    num_detections = int (output_dict.pop('num_detections'))
    output_dict = {key : value[0, :num_detections].numpy()
                    for key,value in output_dict.items()}
    output_dict['num_detections'] = num_detections

    if 'detection_masks' in  output_dict:
        detection_masks_reframed = utils_ops.reframe_box_masks_to_image_masks(output_dict['detection_masks'],
        output_dict['detection_boxes'], image.shape[0], image.shape[1])

        detection_masks_reframed = tf.cast(detection_masks_reframed > 0.5, tf.uint8)
        output_dict["detection_masks_reframed"] = detection_masks_reframed.numpy()

    return output_dict


