import cv2 
from numpy import interp
from collections import deque

from .Detection.Lanes.Lane_Detection import detect_Lane
from .Detection.Signs.SignDetectionApi import detect_Signs
from .Detection.TrafficLights.TrafficLights_Detection import detect_TrafficLights

class Debugging:
    pass

class Control:
    
    def __init__(self):

        self.prev_Mode= "Detection"
        self.prev_Mode_LT = "Detection"

        self.car_speed=80
        self.angle_of_car=0

        self.Left_turn_iterations = 0
        self.Frozen_angle= 0 
        self.Detected_LeftTurn = False
        self.Activat_LeftTurn = False

        self.TrafficLight_iterations = 0
        self.GO_MODE_ACTIVATED = False
        self.STOP_MODE_ACTIVATED = False

        self.angle_queue = deque (maxlen=10)
    
    def follow_Lane(self, Max_Sane_dist, distance, curvature, Mode, Tracked_class):
        IncreaseTireSpeedInTurns = False

        if ((Tracked_class!=0) and (self.prev_Mode =='Tracking') and (Mode == "Detection")):
            if ((Tracked_class == 'speed_sign_30')):
                self.car_speed = 30
            elif ((Tracked_class == 'speed_sign_60')):
                self.car_speed = 60
            elif ((Tracked_class == 'speed_sign_90')):
                self.car_speed = 90
            elif ((Tracked_class == 'stop')):
                self.car_speed = 0
        
        self.prev_Mode= Mode
        Max_turn_angle_neg=-90
        Max_turn_angle=90

        Current_angle= 0

        if ((distance > Max_Sane_dist) or (distance <(-1 * Max_Sane_dist))):
            if (distance > Max_Sane_dist):
                CarTurn_angle= Max_turn_angle +curvature
            else:
                CarTurn_angle= Max_turn_angle_neg +curvature
        else:
            Turn_angle_interpolated = interp (distance, [-Max_Sane_dist, Max_Sane_dist], [-90,90])

            CarTurn_angle=(0.65*Turn_angle_interpolated) + (0.35*curvature)
            
        
        if ((CarTurn_angle > Max_turn_angle) or (CarTurn_angle < (-1 * Max_turn_angle))):
            if (CarTurn_angle > Max_turn_angle):
                CarTurn_angle = Max_turn_angle
            else:
                CarTurn_angle=-Max_turn_angle
    
        angle = interp(CarTurn_angle,[-90,90],[-60,60])

        curr_speed=self.car_speed

        if (IncreaseTireSpeedInTurns and (Tracked_class != "left_turn")):
            if (angle > 30):
                car_speed_turn = interp(angle,[30,45],[80,100])
                curr_speed=car_speed_turn
            elif (angle <-30):
                car_speed_turn = interp (angle,[-45,-30], [100,80])
                curr_speed = car_speed_turn
        
        return angle, curr_speed
    
    def Obey_LeftTurn(self,Angle,Speed,Mode,Tracked_class):
        if (Tracked_class == "left_turn"):
            speed=50

            if ((self.prev_Mode_LT="Detection") and (Mode="Tracking")):
                self.prev_Mode_LT="Tracking"
                self.Detected_LeftTurn= True
            elif ((self.prev_Mode_LT=="Tracking") and (Mode ="Detection")):
                self.Detected_LeftTurn= False
                self.Activat_LeftTurn= True


                if (((self.Left_turn_iterations % 20)==0) and (self.Left_turn_iterations>100)):
                    self.Frozen_Angle = self.Frozen_Angle-7
                if (self.Left_turn_iterations==250):
                    self.prev_Mode_LT="Detection"
                    self.Activat_LeftTurn=False
                    self.Left_turn_iterations=0

                if (self.Activat_LeftTurn or self.Detected_LeftTurn):
                    Angle=Frozen_Angle

        return Angle,Speed,self.Detected_LeftTurn,self.Activat_LeftTurn

    def OBEY_TrafficLights(self,a,b,Traffic_State,CloseProximity):

        if ((Traffic_State == "Stop") and CloseProximity):
            b=0 
            self.STOP_MODE_ACTIVATED=True
        else:
            if (self.STOP_MODE_ACTIVATED or self.GO_MODE_ACTIVATED):
                if (self.STOP_MODE_ACTIVATED and (Traffic_State=="Go")):
                    self.STOP_MODE_ACTIVATED=False
                    self.GO_MODE_ACTIVATED=True
                
                elif (self.STOP_MODE_ACTIVATED):
                    b=0
                elif (self.GO_MODE_ACTIVATED):
                    a=0.0
                    if (self.TrafficLight_iterations ==200):
                        self.GO_MODE_ACTIVATED = False
                        self.TrafficLight_iterations = 0
                    
                    self.TrafficLight_iterations=self.TrafficLight_iterations+1
        
        return a,b
    
    def drive_car(self,Current_State,Inc_TL,Inc_LT):

        [Distance, Curvature, frame_disp, Mode, Tracked_class,Traffic_State,CloseProximity ]= Current_State

        curr_speed= 0 
        if ((Distance != -1000) and (Curvature != -1000)):
            self.angle_of_car, current_speed = self.follow_Lane(int (frame_disp.shape[1]/2),Distance, Curvature,Mode,Tracked_class)
        config.angle_orig = self.angle_of_car

        if Inc_LT:
            self.angle_of_car,current_speed,Detected_LeftTurn, Activat_LeftTurn =self.Obey_LeftTurn(self.angle_of_car,current_speed,Mode,Tracked_class)
        
        else:
            Detected_LeftTurn = False
            Activat_LeftTurn = False

        
        if Inc_TL:
            self.angle_of_car, current_speed= self.OBEY_TrafficLights(self.angle_of_car,current_speed,Tracked_class,CloseProximity)

        return self.angle_of_car, current_speed,Detected_LeftTurn,Activat_LeftTurn





class Car:

    def __init__(self, Inc_TL=True, Inc_LT=True):
        self.Control = Control()
        self.Inc_TL=Inc_TL
        self.Inc_LT= Inc_LT
        self.Tracked_class = "Unkown"
        self.Traffic_State = "Unkown"

    def display_state():
        pass
    def drive_car(self, frame):
        
        img = frame(0:640,238:1042)
        img =cv2.resize(img,(320,240))

        img_orig = img.copy()

        distance, curvature = detect_Lane(img)

        if self.Inc_TL:
            Traffic_State, CloseProximity = detect_TrafficLights(img_orig.copy(),img)
        else:
            Traffic_State= "Unknown"
            CloseProximity = False
        
        Mode, Tracked_class = detect_Signs (img_orig,img)

        Current_State = [distance, curvature, img, Mode, Tracked_class,Traffic_State, CloseProximity]

        Angle, Speed, Detected_LeftTurn, Activat_LeftTurn = self.Control_.drive_car(Current_State,self.Inc_TL,self.Inc_LT)

        self.Tracked_class = Tracked_class
        self.Traffic_State = Traffic_State

        Angle = interp(Angle, [-60,60],[0.8,-0.8])
        if(Speed!= 0):
            Speed= interp(Speed, [30,30],[1,2])
        
        Speed= float(Speed)

        return Angle, Speed, img


